influencers = [
    "elonmusk", "sundarpichai", "satyanadella", "tim_cook",
    "BillGates", "BarackObama", "POTUS", "jack",
    "jeffbezos", "neiltyson"
]

keywords = ["AI", "tech", "innovation", "deal", "GPT"]
